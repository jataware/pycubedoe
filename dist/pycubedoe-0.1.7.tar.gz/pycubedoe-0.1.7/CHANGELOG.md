## 0.1.7 (March 2, 2021)
  - removed exec

## 0.1.6 (February 25, 2021)
  - changed image link

## 0.1.5 (February 25, 2021)
  - changed image link

## 0.1.4 (February 25, 2021)
  - added vignette

## 0.1.3 (February 23, 2021)
  - fix typo

## 0.1.2 (February 23, 2021)
  - format readme

## 0.1.1 (February 23, 2021)
  - added number of design points per number factors

## 0.1.0 (February 23, 2021)
  - Deployment for beta

## 0.0.5 (February 23, 2021)
  - added DOE design point parsing function

## 0.0.4 (February 23, 2021)
  - added acknowledgements and copyright 

## 0.0.3 (February 23, 2021)
  - fixed readme

## 0.0.2 (2021-02-23)
  - changed class parameters

## 0.0.1 (2021-02-17)
  - First release on PyPI.

